

<?php $__env->startSection('title', 'Pizzeria Mostra'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Mostar listado de pedidos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">
      <a class="btn btn-secondary" href="<?php echo e(route('admin.pedidos.create')); ?>">Agregar Pedidos</a>

    </div>


      <div class="card-body">
          <table class="table table-striped">
              <thead>
                  <tr>
                      <th>Id</th>
                      <th>Propietario</th>
                      <th>Tipo de Pedido</th>
                  </tr>
              </thead>

              <tbody>
                  <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td><?php echo e($pedido->id); ?></td>
                          <td><?php echo e($pedido->nombre_propietario); ?></td>
                          <td><?php echo e($pedido->tipo_pedido); ?></td>
                          <td width="10px">
                            <a class="btn btn-success" href="<?php echo e(route('admin.pedidos.show',$pedido)); ?>">
                                Ver
                            </a>
                            </td>
                          <td width="10px">
                              <a class="btn btn-primary" href="<?php echo e(route('admin.pedidos.edit',$pedido)); ?>">
                                  Editar
                              </a>
                          </td>
                          <td width="10px">
                              <form action="<?php echo e(route('admin.pedidos.destroy', $pedido)); ?>" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('delete'); ?>
                                  <button type="submit" class="btn btn-danger">Eliminar</button>
                              </form>
                          </td>
                      </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
      </div>


  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\pizza\resources\views/admin/pedidos/index.blade.php ENDPATH**/ ?>