

<?php $__env->startSection('title', 'Pizzeria Mostra'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear pedidos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php echo Form::open(['route' => 'admin.pedidos.store']); ?> 

            <div class="form-group">
                <?php echo Form::label('tipo_pedido', 'Tipo de Pedido:'); ?>

                <?php echo Form::text('tipo_pedido', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre de el Pedido']); ?>


                <?php $__errorArgs = ['tipo_pedido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('slug', 'Slug:'); ?>

                <?php echo Form::text('slug', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el slug de  el Pedido', 'readonly']); ?>


                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <p class="font-weigth-bold">Productos</p>

                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <label class="mr-2">
                    <?php echo Form::checkbox('productos[]', $producto->id, null); ?>

                    <?php echo e($producto->nombre); ?>

                </label>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php echo Form::hidden('user_id', auth()->user()->id); ?>


            <?php echo Form::submit('Crear Pedido',['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js')); ?>"></script>
    <script>
        $(document).ready( function() {
            $("#tipo_pedido").stringToSlug({
                setEvents: 'keyup keydown blur',
                getPut: '#slug',
                space: '-'
  });
});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\pizza\resources\views/admin/pedidos/create.blade.php ENDPATH**/ ?>