<div>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>"/>

        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>" />
        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/slick-theme.css')); ?>" />

        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/nouislider.min.css')); ?>" />
      <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>"/>
    </head>
    <body>
        <h1>dgwegwhgw</h1>
        <h2>awfewgweg</h2>
        <h3>safewgerheh</h3>
        
    </body>
    </html>
</div>
<?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\pizza\resources\views/livewire/admin/contenido-index.blade.php ENDPATH**/ ?>