

<?php $__env->startSection('title', 'Pizzeria Mostra'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Listado de usuarios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.user-index')->html();
} elseif ($_instance->childHasBeenRendered('KedLjAB')) {
    $componentId = $_instance->getRenderedChildComponentId('KedLjAB');
    $componentTag = $_instance->getRenderedChildComponentTagName('KedLjAB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KedLjAB');
} else {
    $response = \Livewire\Livewire::mount('admin.user-index');
    $html = $response->html();
    $_instance->logRenderedChild('KedLjAB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\pizza\resources\views/admin/users/index.blade.php ENDPATH**/ ?>