

<?php $__env->startSection('title', 'Pizzeria Mostra'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Mostrar detalle de pedidos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php echo Form::model($pedido, ['route' => ['admin.pedidos.show', $pedido], 'method' => 'put']); ?> 

            <div class="form-group">
                <?php echo Form::label('nombre_propietario', 'Nombre de Propietario'); ?>

                <?php echo Form::text('nombre_propietario', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre de la Categoria', 'readonly']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('tipo_pedido', 'Tipo de Pedido'); ?>

                <?php echo Form::text('tipo_pedido', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el slug de  la Categoria', 'readonly']); ?>

            </div>

            <?php echo Form::label('tipo_pedido', 'Productos'); ?>

            
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
            <?php echo Form::text('', $producto->nombre, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre de la Categoria', 'readonly']); ?>

            </div>
             
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php echo Form::submit('Regresar',['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\pizza\resources\views/admin/pedidos/show.blade.php ENDPATH**/ ?>