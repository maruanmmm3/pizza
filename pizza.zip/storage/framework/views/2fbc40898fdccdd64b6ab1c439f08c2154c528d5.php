<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <style>
        h1{
            color:aqua;
        }
    </style>
</head>
<body>
    <h1>Correo Electronico</h1>
    <p>Este es mi primer correo</p>

    <p><strong>Nombre:</strong> <?php echo e($contacto['name']); ?></p>
    <p><strong>Correo:</strong> <?php echo e($contacto['correo']); ?></p>
    <p><strong>Mensaje:</strong> <?php echo e($contacto['mensaje']); ?></p>
</body>
</html><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\pizza\resources\views/emails/contactanos.blade.php ENDPATH**/ ?>