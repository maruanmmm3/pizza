<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>



    <div class="min-h-screen flex mt-5 px-4">
        <div class='overflow-x-auto w-full'>

    <table class="table-fixed border-separate border border-green-800">
        <thead>
          <tr>
            <th class="w-1/2 ...">Costos</th>
            <th class="w-1/4 ...">Precio de Productos</th>
            <th class="w-1/4 ...">Total a Pagar</th>
           
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($producto->nombre); ?></td>
            <td><?php echo e($producto->precio); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          <tr>
            <td>Monto</td>
            <td class="bg-blue-200"><?php echo e($total); ?></td>
          </tr>
       
            <td>Impuesto</td>
            <td>$0</td>
         
          <tr>
            <td>Delivery</td>
            <td>$10</td>
            <td class="bg-blue-200">$<?php echo e($total +10); ?></td>
          </tr>
        </tbody>
      </table>
      <br>

      <?php echo Form::open(['route' => 'productos.addToPedido']); ?>


      <div class="form-group">
       
        <?php echo Form::label('tipo_pedido', 'Tipo de Envio'); ?>

        <?php echo Form::select('tipo_pedido', ['Envio' => 'Envio', 'Recoje' => 'Recoje'], null, ['placeholder' => 'Selecciona tipo de envio']); ?>


        <?php echo Form::submit('Enviar Pedido', ['class' => 'bg-blue-500 px-4 py-2 text-xs font-semibold tracking-wider text-white rounded hover:bg-blue-600 mt-5']); ?>

  
      </div>

      

      <div class="form-group">
        <?php echo Form::hidden('user_id', auth()->user()->id); ?>

      </div>

      <div class="form-group">
        <?php echo Form::hidden('nombre_propietario', auth()->user()->name); ?>

      </div>

      <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <label>
        <?php echo Form::checkbox('productos[]', $producto->id, true, ['class' => 'invisible']); ?>

      </label>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php echo Form::close(); ?>

     
    
    
        </div>
    </div>
    
</div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\pizza\resources\views/productos/ordernow.blade.php ENDPATH**/ ?>