

<?php $__env->startSection('title', 'Pizzeria Mostra'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Productos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('info')): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session('info')); ?></strong>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body">

        <?php echo Form::model($producto,['route' => ['admin.productos.update', $producto], 'files' => true, 'method' => 'put']); ?>

            <div class="form-group">
                <?php echo Form::label('nombre', 'Nombre:'); ?>

                <?php echo Form::text('nombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre de el Producto']); ?>


                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('slug', 'Slug:'); ?>

                <?php echo Form::text('slug', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el slug de el Producto', 'readonly']); ?>


                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('precio', 'Precio:'); ?>

                <?php echo Form::text('precio', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el precio de el Producto']); ?>


                <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('categoria_id', 'Categoria:'); ?>

                <?php echo Form::select('categoria_id', $categorias, null, ['class' => 'form-control']); ?>


                <?php $__errorArgs = ['categoria_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="row mb-3">

                <div class="col">
                    <div class="image-wrapper">
                        <?php if(isset($producto->imagen)): ?>
                            <img id="picture" src="<?php echo e(Storage::url($producto->imagen->url)); ?>">
                        <?php else: ?>
                            <img id="picture" src="https://cdn.pixabay.com/photo/2016/02/19/11/30/pizza-1209748_1280.jpg" alt="">
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <?php echo Form::label('file', 'Imagen que se mostrara en el Producto'); ?>

                        <?php echo Form::file('file', ['class' => 'form-control-file', 'accept' => 'image/*']); ?>


                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <p>Aqui pondremos las indicaciones de la imagen </p>
                </div>

            </div>

            <div class="form-group">
                <?php echo Form::label('descripcion', 'Descripcion:'); ?>

                <?php echo Form::textArea('descripcion', null, ['class' => 'form-control', 'placeholder' => 'Ingrese la descripcion de el Producto']); ?>


                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <?php echo Form::submit('Actualizar Producto',['class' => 'btn btn-primary']); ?>


        <?php echo Form::close(); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .image-wrapper{
            position: relative;
            padding-bottom: 56.25%;
        }
        .image-wrapper img{
            position: absolute;
            object-fit: cover;
            width: 100%;
            height: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js')); ?>"></script>
    <script>
        $(document).ready( function() {
            $("#nombre").stringToSlug({
                setEvents: 'keyup keydown blur',
                getPut: '#slug',
                space: '-'
  });
});

//Cambiar imagen
        document.getElementById("file").addEventListener('change', cambiarImagen);

        function cambiarImagen(event){
            var file = event.target.files[0];

            var reader = new FileReader();
            reader.onload = (event) => {
                document.getElementById("picture").setAttribute('src', event.target.result); 
            };

            reader.readAsDataURL(file);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Documents\xampp\htdocs\pizza\resources\views/admin/productos/edit.blade.php ENDPATH**/ ?>