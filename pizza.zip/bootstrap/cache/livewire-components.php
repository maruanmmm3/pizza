<?php return array (
  'admin.user-index' => 'App\\Http\\Livewire\\Admin\\UserIndex',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);